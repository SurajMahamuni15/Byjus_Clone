package com.example.byjusclone

object Constance {
    const val LESSON = "lesson"
    const val POSITION = "position"
    const val CHAPTERS = "chapters"
    const val CHAPTER_TITLE = "chapterTitle"
}