package com.example.byjusclone.viewHolder

import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.byjusclone.databinding.LessonItemBinding

class LessonViewHolder(val binding: LessonItemBinding) : ViewHolder(binding.root)