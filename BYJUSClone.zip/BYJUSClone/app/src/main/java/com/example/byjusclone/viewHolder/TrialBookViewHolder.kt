package com.example.byjusclone.viewHolder

import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.byjusclone.databinding.FreeTrialBookItemBinding

class TrialBookViewHolder(val binding: FreeTrialBookItemBinding) : ViewHolder(binding.root)