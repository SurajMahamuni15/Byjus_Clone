package com.example.byjusclone.viewHolder

import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.byjusclone.databinding.HomeMainItemBinding

class HomeMainViewHolder(val mainBinding: HomeMainItemBinding) : ViewHolder(mainBinding.root)