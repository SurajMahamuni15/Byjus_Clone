package com.example.byjusclone.viewHolder

import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.byjusclone.databinding.ChapterItemBinding

class ChapterViewHolder(val chapterBinding : ChapterItemBinding ) : ViewHolder(chapterBinding.root)