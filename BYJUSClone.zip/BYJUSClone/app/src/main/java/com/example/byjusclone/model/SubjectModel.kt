package com.example.byjusclone.model

data class SubjectModel(
    val img: Int,
    val subjectTitle: String,
    val chapterModel: ArrayList<ChapterModel>
)