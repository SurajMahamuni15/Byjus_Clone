package com.example.byjusclone

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ByjusApplication : Application() {
}