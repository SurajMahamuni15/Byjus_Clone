package com.example.byjusclone.model

data class HomeMainModel(
    var title: String,
    var type: String,
    var subject: ArrayList<SubjectModel>
)
