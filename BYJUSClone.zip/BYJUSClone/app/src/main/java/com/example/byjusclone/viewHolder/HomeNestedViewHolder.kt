package com.example.byjusclone.viewHolder

import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.byjusclone.databinding.HomeNestedItemBinding

class HomeNestedViewHolder(val nestedBinding: HomeNestedItemBinding) : ViewHolder(nestedBinding.root)