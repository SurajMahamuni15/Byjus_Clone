package com.example.byjusclone.viewHolder

import androidx.recyclerview.widget.RecyclerView
import com.example.byjusclone.databinding.VideoPlaylistItemBinding

class VideoPlayListViewHolder(val binding : VideoPlaylistItemBinding) : RecyclerView.ViewHolder(binding.root)